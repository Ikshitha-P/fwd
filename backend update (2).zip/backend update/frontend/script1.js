
let isLoggedIn = false;
let cart = [];
let cartCount = 0;

document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = event.target.querySelector('input[type="text"]').value;
    const password = event.target.querySelector('input[type="password"]').value;

    if (username && password) {
        isLoggedIn = true;
        alert("Login Successful!");
        document.getElementById('home-page').style.display = 'block';
        document.getElementById('signup').style.display = 'none';
        document.getElementById('login').style.display = 'none';
    } else {
        alert("Please fill in both username and password.");
    }
});

function addToCart(item, price, imageUrl) {
    const existingItem = cart.find(cartItem => cartItem.item === item);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ item, price, imageUrl, quantity: 1 });
    }

    cartCount++;
    localStorage.setItem('cart', JSON.stringify(cart)); // Save cart to localStorage
    document.getElementById('cart-count').textContent = cartCount;
}


function viewCart() {
    // Store cart data in localStorage before redirecting
    localStorage.setItem('cart', JSON.stringify(cart));

    // Redirect to the cart page
    window.location.href = 'cart.html';
}


function closeCart() {
    document.getElementById('cart-modal').style.display = 'none';
}

function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Close cart modal
    closeCart();

    // Display payment modal
    const paymentModal = document.getElementById('payment-modal');
    paymentModal.style.display = 'block';

    // Handle payment confirmation
    document.getElementById('payment-form').onsubmit = function(event) {
        event.preventDefault();
        
        const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
        alert(`Payment successful! Method: ${paymentMethod}`);

        // Clear cart and reset count
        cart = [];
        cartCount = 0;
        document.getElementById('cart-count').textContent = cartCount;

        // Close payment modal
        closePayment();
    };
}

function closePayment() {
    document.getElementById('payment-modal').style.display = 'none';
}

function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Close cart modal
    closeCart();

    // Display payment modal
    const paymentModal = document.getElementById('payment-modal');
    paymentModal.style.display = 'block';

    // Handle payment confirmation
    document.getElementById('payment-form').onsubmit = function(event) {
        event.preventDefault();
        
        const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
        alert(`Payment successful! Method: ${paymentMethod}`);

        // Display the order summary
        showOrderSummary();

        // Clear cart and reset count
        cart = [];
        cartCount = 0;
        document.getElementById('cart-count').textContent = cartCount;

        // Close payment modal
        closePayment();
    };
}

function showOrderSummary() {
    // Hide the payment modal
    document.getElementById('payment-modal').style.display = 'none';

    // Show the order summary section
    const orderSummary = document.getElementById('order-summary');
    const orderItems = document.getElementById('order-items');
    
    // Clear previous order items
    orderItems.innerHTML = '';

    // Add each item in the cart to the order summary
    cart.forEach((entry) => {
        orderItems.innerHTML += `
            <div class="order-item">
                <img src="${entry.imageUrl}" alt="${entry.item}" style="width: 50px; height: 50px;">
                <div class="item-details">
                    <h3>${entry.item}</h3>
                    <p>Price: ₹${entry.price} | Quantity: ${entry.quantity}</p>
                    <p>Total: ₹${entry.price * entry.quantity}</p>
                </div>
            </div>
        `;
    });

    // Display the order summary section
    orderSummary.style.display = 'block';
}

function backToHomePage() {
    // Hide the order summary
    document.getElementById('order-summary').style.display = 'none';

    // Show the home page again
    document.getElementById('home-page').style.display = 'block';
    document.getElementById('sign-up').style.display = 'none';
    document.getElementById('login').style.display = 'none';

}