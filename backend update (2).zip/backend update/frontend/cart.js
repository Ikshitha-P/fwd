// Load cart data from localStorage
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let cartCount = cart.reduce((count, entry) => count + entry.quantity, 0);

// Display the cart items
function displayCartItems() {
    const cartItemsDiv = document.getElementById('cart-items');
    const totalPriceElem = document.getElementById('total-price');
    
    cartItemsDiv.innerHTML = ''; // Clear current items
    let totalPrice = 0;

    cart.forEach((entry) => {
        cartItemsDiv.innerHTML += `
            <div class="cart-item">
                <img src="${entry.imageUrl}" alt="${entry.item}" />
                <div class="item-details">
                    <h3>${entry.item}</h3>
                    <p>Price: ₹${entry.price} | Quantity: ${entry.quantity}</p>
                </div>
                <div class="price">₹${entry.price * entry.quantity}</div>
            </div>
        `;
        totalPrice += entry.price * entry.quantity;
    });

    totalPriceElem.textContent = `Total: ₹${totalPrice}`;
}

// Handle the checkout process
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Hide the cart section and show payment section
    document.getElementById('cart-section').style.display = 'none';
    document.getElementById('payment-section').style.display = 'block';
}

// Handle payment confirmation
document.getElementById('payment-form').onsubmit = function(event) {
    event.preventDefault();
    const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
    
    alert(`Payment successful! Method: ${paymentMethod}`);

    // Show the order summary after successful payment
    showOrderSummary();

    // Clear cart from localStorage
    localStorage.removeItem('cart');
};

// Show order summary
function showOrderSummary() {
    document.getElementById('payment-section').style.display = 'none';
    document.getElementById('order-summary').style.display = 'block';

    const orderItemsDiv = document.getElementById('order-items');
    orderItemsDiv.innerHTML = ''; // Clear current order items

    cart.forEach((entry) => {
        orderItemsDiv.innerHTML += `
            <div class="order-item">
                <img src="${entry.imageUrl}" alt="${entry.item}" style="width: 50px; height: 50px;">
                <div class="item-details">
                    <h3>${entry.item}</h3>
                    <p>Price: ₹${entry.price} | Quantity: ${entry.quantity}</p>
                    <p>Total: ₹${entry.price * entry.quantity}</p>
                </div>
            </div>
        `;
    });
}

// Back to home page from order summary
function backToHomePage() {
    window.location.href = 'fwd.html';
}

// Initialize the page by displaying the cart items
displayCartItems();